var Bricks = [
	{
		// 1
		art: 1,
		color: 'yellow',
		type: 'animal',
		name: 'bird'
	},
	{
		// 2
		art: 2,
		color: 'green',
		type: 'animal',
		name: 'bird'
	},
	{
		// 3
		art: 3,
		color: 'blue',
		type: 'animal',
		name: 'bird'
	},
	{
		// 4
		art: 4,
		color: 'red',
		type: 'animal',
		name: 'bird'
	},
	{
		// 5
		art: 5,
		color: 'blue',
		type: 'car',
		name: 'car'
	},
	{
		// 6
		art: 6,
		color: 'blue',
		type: 'animal',
		name: 'fish'
	},
	{
		// 7
		art: 7,
		color: 'red',
		type: 'animal',
		name: 'squirell'
	},
	{
		// 8
		art: 8,
		color: 'yellow',
		type: 'glass',
		name: 'glass'
	},
	{
		// 9
		art: 9,
		color: 'green',
		type: 'music',
		name: 'music'
	},
	{
		// 10
		art: 10,
		color: 'gray',
		type: 'animal',
		name: 'cat'
	}

];